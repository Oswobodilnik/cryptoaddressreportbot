from django.db import models

# Create your models here.









class Report(models.Model):
	crypto_address = models.CharField(max_length=5000)
	message = models.CharField(max_length=5000)
	username = models.CharField(max_length=5000)
	userid = models.CharField(max_length=5000)


	def __str__(self):
		return self.crypto_address



class BlockUser(models.Model):
	username = models.CharField(max_length=5000,default="No Username")
	userid = models.CharField(max_length=5000)


	def __str__(self):
		return self.username