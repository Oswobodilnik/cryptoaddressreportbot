from django.urls import path
from . views import *



urlpatterns = [
    
    #path('allpost/', AllPostView, name='allpost'),
    #path('', csv_database_write, name='homepage'),







    ]