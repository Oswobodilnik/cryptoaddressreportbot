from django.shortcuts import render,redirect
#from .models import Accounts

from django.http import HttpResponse
import csv

# Create your views here.